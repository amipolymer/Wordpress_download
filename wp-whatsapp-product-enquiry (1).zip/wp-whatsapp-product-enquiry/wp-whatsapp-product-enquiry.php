<?php
/*
Plugin Name: WP WhatsApp Product Enquiry
Description: WooCommerce WhatsApp enquiry button with floating button, analytics, styling and position controls.
Version: 1.0.0
*/

if (!defined('ABSPATH')) exit;

class WP_WhatsApp_Product_Enquiry {

    public function __construct() {
        add_action('admin_menu', [$this,'menu']);
        add_action('admin_init', [$this,'settings']);
        add_action('woocommerce_after_add_to_cart_button', [$this,'render_button']);
        add_action('wp_footer', [$this,'floating_button']);
    }

    public function menu(){
        add_menu_page('WhatsApp Enquiry','WhatsApp Enquiry','manage_options','wpwa-enquiry',[$this,'page']);
    }

    public function settings(){
        foreach([
            'wpwa_number','wpwa_text','wpwa_message','wpwa_bg','wpwa_color',
            'wpwa_custom_class','wpwa_floating'
        ] as $o){
            register_setting('wpwa_group',$o);
        }
    }

    public function page(){ ?>
        <div class="wrap">
            <h1>WP WhatsApp Product Enquiry</h1>
            <form method="post" action="options.php">
                <?php settings_fields('wpwa_group'); ?>
                <table class="form-table">
                    <tr><th>WhatsApp Number</th><td><input class="regular-text" name="wpwa_number" value="<?php echo esc_attr(get_option('wpwa_number')); ?>"></td></tr>
                    <tr><th>Button Text</th><td><input class="regular-text" name="wpwa_text" value="<?php echo esc_attr(get_option('wpwa_text','WhatsApp')); ?>"></td></tr>
                    <tr><th>Default Message</th><td><textarea name="wpwa_message" rows="5" cols="60"><?php echo esc_textarea(get_option('wpwa_message','Hello, I am interested in this product.')); ?></textarea></td></tr>
                    <tr><th>Button Background</th><td><input type="color" name="wpwa_bg" value="<?php echo esc_attr(get_option('wpwa_bg','#25D366')); ?>"></td></tr>
                    <tr><th>Button Text Color</th><td><input type="color" name="wpwa_color" value="<?php echo esc_attr(get_option('wpwa_color','#ffffff')); ?>"></td></tr>
                    <tr><th>Custom CSS Class</th><td><input class="regular-text" name="wpwa_custom_class" value="<?php echo esc_attr(get_option('wpwa_custom_class')); ?>"></td></tr>
                    <tr><th>Floating Button</th><td><input type="checkbox" name="wpwa_floating" value="1" <?php checked(get_option('wpwa_floating',1),1); ?>></td></tr>
                </table>
                <?php submit_button(); ?>
            </form>
        </div>
    <?php }

private function wa_url($product){

    $num = preg_replace('/[^0-9]/', '', get_option('wpwa_number'));

    if (strlen($num) === 10) {
        $num = '91' . $num;
    }

    // CLEAN PRODUCT NAME
    $product_name = html_entity_decode($product->get_name(), ENT_QUOTES, 'UTF-8');

    // CLEAN PRICE (IMPORTANT FIX)
    $price = wp_strip_all_tags($product->get_price_html());
    $price = html_entity_decode($price, ENT_QUOTES, 'UTF-8');

    // BUILD MESSAGE (STRICT FORMAT)
    $message  = "Product Enquiry";
    $message  = "Hi, I am interested in this product - ";
    $message .= "\n" . $product_name;
    // $message .= " || \n\nPrice:\n" . $price;
    $message .= " || \n\nURL:\n" . get_permalink($product->get_id());

   

    return 'https://wa.me/' . $num . '?text=' . urlencode($message);
}

    public function render_button(){
        if(!is_product()) return;
        global $product;
        if(!$product) return;

        $class = sanitize_title($product->get_name());
        echo '<a target="_blank" href="'.esc_url($this->wa_url($product)).'" class="wpwa-btn '.esc_attr(get_option('wpwa_custom_class')).' product-'.$class.'" style="background:'.esc_attr(get_option('wpwa_bg','#25D366')).';color:'.esc_attr(get_option('wpwa_color','#fff')).';padding:11px 20px;border-radius:6px;text-decoration:none;display:inline-block;margin-top:0px;">';
        echo esc_html(get_option('wpwa_text','WhatsApp Enquiry'));
        echo '</a>';
    }

    public function floating_button(){
        if(!get_option('wpwa_floating',1)) return;
        $num = preg_replace('/[^0-9]/','',get_option('wpwa_number'));
        $raw = trim(get_option('wpwa_number'));

$num = preg_replace('/[^0-9]/', '', $raw);

// Auto-add India country code if only 10 digits entered
if (strlen($num) === 10) {
    $num = '91' . $num;
}

        if(!$num) return;

        echo '<a target="_blank" href="https://wa.me/'.$num.'" style="position:fixed;right:20px;bottom:20px;z-index:9999;background:#25D366;color:#fff;padding:14px 16px;border-radius:50%;text-decoration:none;">💬</a>';
    }
}

new WP_WhatsApp_Product_Enquiry();
