<?php
/*
Plugin Name: Video Play on Product Page
Description: Play YouTube Shorts on WooCommerce product page with autoplay, position, size & reel behavior.
Version: 2.2
Author: Custom
*/

if (!defined('ABSPATH')) exit;

register_activation_hook(__FILE__, function () {
    add_option('pvr_enable', 1);
    add_option('pvr_autoplay', 1);
    add_option('pvr_position', 'right');
    add_option('pvr_pos_vertical', 'bottom');
    add_option('pvr_offset_x', 20);
    add_option('pvr_offset_y', 30);
    add_option('pvr_width', 260);
    add_option('pvr_height', 460);
    add_option('pvr_start', 0);
    add_option('pvr_end', 0);
});

add_action('admin_menu', function () {
    add_menu_page('Video Reels', 'Video Reels', 'manage_options', 'pvr-settings', 'pvr_settings_page');
});

function pvr_settings_page() {
?>
<div class="wrap">
    <h2>Video Settings</h2>
    <form method="post" action="options.php">
        <?php settings_fields('pvr_group'); do_settings_sections('pvr-settings'); submit_button(); ?>
    </form>
</div>
<?php
}

add_action('admin_init', function () {

    register_setting('pvr_group','pvr_enable');
    register_setting('pvr_group','pvr_autoplay');
    register_setting('pvr_group','pvr_position');
    register_setting('pvr_group','pvr_pos_vertical');
    register_setting('pvr_group','pvr_offset_x');
    register_setting('pvr_group','pvr_offset_y');
    register_setting('pvr_group','pvr_width');
    register_setting('pvr_group','pvr_height');
    register_setting('pvr_group','pvr_start');
    register_setting('pvr_group','pvr_end');

    add_settings_section('pvr_sec','',null,'pvr-settings');

    add_settings_field('pvr_enable','Enable',function(){
        echo '<input type="checkbox" name="pvr_enable" value="1" '.checked(1,get_option('pvr_enable'),false).'>';
    },'pvr-settings','pvr_sec');

    add_settings_field('pvr_autoplay','Autoplay',function(){
        echo '<input type="checkbox" name="pvr_autoplay" value="1" '.checked(1,get_option('pvr_autoplay'),false).'>';
    },'pvr-settings','pvr_sec');

    add_settings_field('pvr_position','Horizontal',function(){
        ?>
        <select name="pvr_position">
            <option value="left" <?php selected(get_option('pvr_position'),'left'); ?>>Left</option>
            <option value="right" <?php selected(get_option('pvr_position'),'right'); ?>>Right</option>
        </select>
        <?php
    },'pvr-settings','pvr_sec');

    add_settings_field('pvr_pos_vertical','Vertical',function(){
        ?>
        <select name="pvr_pos_vertical">
            <option value="top" <?php selected(get_option('pvr_pos_vertical'),'top'); ?>>Top</option>
            <option value="bottom" <?php selected(get_option('pvr_pos_vertical'),'bottom'); ?>>Bottom</option>
        </select>
        <?php
    },'pvr-settings','pvr_sec');

    add_settings_field('pvr_offset_x','Offset X',function(){
        echo '<input type="number" name="pvr_offset_x" value="'.esc_attr(get_option('pvr_offset_x')).'">';
    },'pvr-settings','pvr_sec');

    add_settings_field('pvr_offset_y','Offset Y',function(){
        echo '<input type="number" name="pvr_offset_y" value="'.esc_attr(get_option('pvr_offset_y')).'">';
    },'pvr-settings','pvr_sec');

    add_settings_field('pvr_width','Width',function(){
        echo '<input type="number" name="pvr_width" value="'.esc_attr(get_option('pvr_width')).'">';
    },'pvr-settings','pvr_sec');

    add_settings_field('pvr_height','Height',function(){
        echo '<input type="number" name="pvr_height" value="'.esc_attr(get_option('pvr_height')).'">';
    },'pvr-settings','pvr_sec');

    add_settings_field('pvr_start','Start',function(){
        echo '<input type="number" name="pvr_start" value="'.esc_attr(get_option('pvr_start')).'">';
    },'pvr-settings','pvr_sec');

    add_settings_field('pvr_end','End',function(){
        echo '<input type="number" name="pvr_end" value="'.esc_attr(get_option('pvr_end')).'">';
    },'pvr-settings','pvr_sec');
});

add_action('add_meta_boxes', function () {
    add_meta_box('pvr_video','Product Video URL',function($post){
        $url = get_post_meta($post->ID,'_pvr_video',true);
        echo '<input type="text" name="pvr_video" value="'.esc_attr($url).'" style="width:100%;">';
    },'product');
});

add_action('save_post', function($id){
    if(isset($_POST['pvr_video'])){
        update_post_meta($id,'_pvr_video',sanitize_text_field($_POST['pvr_video']));
    }
});

function pvr_get_id($url){
    if(strpos($url,'shorts/')!==false){
        preg_match('/shorts\/([^\?]+)/',$url,$m);
        return $m[1]??'';
    }
    if(strpos($url,'watch?v=')!==false){
        parse_str(parse_url($url,PHP_URL_QUERY),$p);
        return $p['v']??'';
    }
    if(strpos($url,'youtu.be/')!==false){
        return basename(parse_url($url,PHP_URL_PATH));
    }
    return '';
}

add_action('woocommerce_before_single_product_summary', function(){

    if(!get_option('pvr_enable')) return;

    $url = get_post_meta(get_the_ID(),'_pvr_video',true);
    $id = pvr_get_id($url);
    if(!$id) return;

    $autoplay = get_option('pvr_autoplay')?1:0;
    $start = intval(get_option('pvr_start'));
    $end = intval(get_option('pvr_end'));

    $style = get_option('pvr_pos_vertical').':'.get_option('pvr_offset_y').'px;'.
             get_option('pvr_position').':'.get_option('pvr_offset_x').'px;'.
             'width:'.get_option('pvr_width').'px;height:'.get_option('pvr_height').'px;';
?>

<div class="pvr-box" style="<?php echo $style; ?>">
<iframe class="pvr-yt"
src="https://www.youtube.com/embed/<?php echo $id; ?>?enablejsapi=1&mute=1&loop=1&playlist=<?php echo $id; ?>&autoplay=<?php echo $autoplay; ?>&start=<?php echo $start; ?>&end=<?php echo $end; ?>"
allow="autoplay"></iframe>
</div>

<?php
},5);

add_action('wp_enqueue_scripts', function(){
    if(is_product()){
        wp_enqueue_style('pvr-css',plugin_dir_url(__FILE__).'assets/style.css');
        wp_enqueue_script('pvr-js',plugin_dir_url(__FILE__).'assets/script.js',[],false,true);
    }
});
