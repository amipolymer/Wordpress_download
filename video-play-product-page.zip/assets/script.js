let players=[];
function onYouTubeIframeAPIReady(){
document.querySelectorAll('.pvr-yt').forEach((el,i)=>{
players[i]=new YT.Player(el,{events:{onStateChange:function(e){
if(e.data===YT.PlayerState.ENDED){e.target.playVideo();}
}}});
let observer=new IntersectionObserver(entries=>{
entries.forEach(en=>{
if(en.isIntersecting){
players.forEach(p=>p.pauseVideo());
players[i].playVideo();
}else{players[i].pauseVideo();}
});
},{threshold:0.6});
observer.observe(el);
});
}
let tag=document.createElement('script');
tag.src="https://www.youtube.com/iframe_api";
document.body.appendChild(tag);
