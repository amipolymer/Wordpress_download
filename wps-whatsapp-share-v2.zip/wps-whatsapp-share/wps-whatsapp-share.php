<?php
/**
 * Plugin Name: WPS WhatsApp Share
 * Plugin URI:  https://example.com/wps-whatsapp-share
 * Description: Simple WhatsApp share button for WooCommerce single product pages.
 * Version:     1.0.2
 * Author:      WPS WhatsApp Share
 * Text Domain: wps-whatsapp-share
 */

defined( 'ABSPATH' ) || exit;

define( 'WPS_VERSION', '1.0.2' );
define( 'WPS_FILE', __FILE__ );
define( 'WPS_PATH', plugin_dir_path( __FILE__ ) );
define( 'WPS_URL', plugin_dir_url( __FILE__ ) );

require_once WPS_PATH . 'includes/class-wps-settings.php';
require_once WPS_PATH . 'includes/class-wps-render.php';

add_action( 'plugins_loaded', function () {
	WPS_Settings::init();

	if ( class_exists( 'WooCommerce' ) ) {
		WPS_Render::init();
		return;
	}

	add_action( 'admin_notices', function () {
		if ( ! current_user_can( 'activate_plugins' ) ) {
			return;
		}
		echo '<div class="notice notice-warning"><p>' . esc_html__( 'WPS WhatsApp Share requires WooCommerce to be active.', 'wps-whatsapp-share' ) . '</p></div>';
	} );
} );

register_activation_hook( __FILE__, function () {
	if ( ! get_option( WPS_Settings::OPTION ) ) {
		add_option( WPS_Settings::OPTION, WPS_Settings::defaults() );
	}
} );
