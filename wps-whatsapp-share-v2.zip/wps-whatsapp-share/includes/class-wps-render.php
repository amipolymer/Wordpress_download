<?php
defined( 'ABSPATH' ) || exit;

class WPS_Render {

	private static $done = false;

	public static function init() {
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_action( 'woocommerce_single_product_summary', array( __CLASS__, 'render_before_cart' ), 29 );
		add_action( 'woocommerce_single_product_summary', array( __CLASS__, 'render_after_cart' ), 32 );
		add_action( 'woocommerce_single_product_summary', array( __CLASS__, 'render_after_summary' ), 45 );
		add_action( 'woocommerce_after_add_to_cart_button', array( __CLASS__, 'render_after_cart' ), 20 );
		add_action( 'woocommerce_before_add_to_cart_button', array( __CLASS__, 'render_before_cart' ), 20 );
		add_action( 'blonwe_single_add_to_cart', array( __CLASS__, 'render_after_cart' ), 35 );
		add_action( 'blonwe_single_add_to_cart', array( __CLASS__, 'render_before_cart' ), 25 );
	}

	public static function assets() {
		if ( ! is_product() ) {
			return;
		}

		$settings = WPS_Settings::get();
		if ( 'yes' !== $settings['enabled'] ) {
			return;
		}

		wp_enqueue_style( 'wps-front', WPS_URL . 'assets/css/front.css', array(), WPS_VERSION );
		wp_add_inline_style(
			'wps-front',
			'.wps-whatsapp-btn{background-color:' . esc_attr( $settings['color'] ) . ';}'
		);
	}

	public static function render_before_cart() {
		self::render_for_position( 'before_add_to_cart' );
	}

	public static function render_after_cart() {
		self::render_for_position( 'after_add_to_cart' );
	}

	public static function render_after_summary() {
		self::render_for_position( 'after_summary' );
	}

	private static function render_for_position( $expected ) {
		if ( self::$done || ! is_product() ) {
			return;
		}

		$settings = WPS_Settings::get();
		if ( 'yes' !== $settings['enabled'] || $expected !== $settings['position'] ) {
			return;
		}

		self::render();
	}

	public static function render() {
		if ( self::$done || ! is_product() ) {
			return;
		}

		global $product;

		if ( ! $product instanceof WC_Product ) {
			$product = wc_get_product( get_the_ID() );
		}

		if ( ! $product instanceof WC_Product ) {
			return;
		}

		$settings = WPS_Settings::get();
		if ( 'yes' !== $settings['enabled'] ) {
			return;
		}

		$message = self::build_message( $product, $settings );
		$url     = self::build_url( $message, $settings );

		$html = sprintf(
			'<div class="wps-whatsapp-wrap"><a href="%s" class="wps-whatsapp-btn" target="_blank" rel="noopener noreferrer" aria-label="%s">%s<span>%s</span></a></div>',
			esc_url( $url ),
			esc_attr__( 'Share on WhatsApp', 'wps-whatsapp-share' ),
			self::icon(),
			esc_html__( 'WhatsApp', 'wps-whatsapp-share' )
		);

		self::$done = true;
		echo apply_filters( 'wps_whatsapp_share_output', $html, $product, $settings, $message ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	private static function build_url( $message, $settings ) {
		$number = preg_replace( '/[^0-9]/', '', $settings['whatsapp_number'] ?? '' );
		$base   = $number ? 'https://wa.me/' . $number : 'https://wa.me/';

		return apply_filters(
			'wps_whatsapp_share_url',
			$base . '?text=' . rawurlencode( $message ),
			$message,
			$settings
		);
	}

	private static function build_message( $product, $settings ) {
		$text = trim( $settings['message'] );
		$text = apply_filters( 'wps_whatsapp_share_message', $text, $product, $settings );

		return sprintf(
			'%s - %s. %s',
			$text,
			$product->get_name(),
			get_permalink( $product->get_id() )
		);
	}

	private static function icon() {
		return '<svg class="wps-whatsapp-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.435 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>';
	}
}
