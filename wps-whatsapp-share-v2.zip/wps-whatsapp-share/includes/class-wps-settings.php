<?php
defined( 'ABSPATH' ) || exit;

class WPS_Settings {

	const OPTION = 'wps_settings';

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_init', array( __CLASS__, 'register' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'admin_assets' ) );
	}

	public static function defaults() {
		return apply_filters(
			'wps_whatsapp_share_default_settings',
			array(
				'enabled'          => 'yes',
				'whatsapp_number'  => '',
				'color'            => '#25D366',
				'message'          => 'Hi I am interested on this product',
				'position'         => 'after_add_to_cart',
			)
		);
	}

	public static function get() {
		return wp_parse_args( get_option( self::OPTION, array() ), self::defaults() );
	}

	public static function admin_assets( $hook ) {
		if ( 'settings_page_wps-whatsapp-share' !== $hook ) {
			return;
		}
		wp_enqueue_style( 'wp-color-picker' );
		wp_enqueue_script( 'wp-color-picker' );
	}

	public static function menu() {
		add_options_page(
			__( 'WPS WhatsApp Share', 'wps-whatsapp-share' ),
			__( 'WPS WhatsApp Share', 'wps-whatsapp-share' ),
			'manage_options',
			'wps-whatsapp-share',
			array( __CLASS__, 'page' )
		);
	}

	public static function register() {
		register_setting( 'wps_settings_group', self::OPTION, array( __CLASS__, 'sanitize' ) );
	}

	public static function sanitize( $input ) {
		$out       = self::defaults();
		$positions = array( 'after_add_to_cart', 'before_add_to_cart', 'after_summary' );

		$out['enabled']          = ! empty( $input['enabled'] ) && 'yes' === $input['enabled'] ? 'yes' : 'no';
		$out['whatsapp_number']  = preg_replace( '/[^0-9]/', '', $input['whatsapp_number'] ?? '' );
		$out['color']            = sanitize_hex_color( $input['color'] ?? $out['color'] ) ?: $out['color'];
		$out['message']          = sanitize_text_field( $input['message'] ?? $out['message'] );
		$out['position']         = in_array( $input['position'] ?? '', $positions, true ) ? $input['position'] : $out['position'];

		return apply_filters( 'wps_whatsapp_share_sanitize_settings', $out, $input );
	}

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$s = self::get();
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'WPS WhatsApp Share', 'wps-whatsapp-share' ); ?></h1>
			<form method="post" action="options.php">
				<?php settings_fields( 'wps_settings_group' ); ?>
				<table class="form-table">
					<tr>
						<th><?php esc_html_e( 'Button', 'wps-whatsapp-share' ); ?></th>
						<td>
							<select name="<?php echo esc_attr( self::OPTION ); ?>[enabled]">
								<option value="yes" <?php selected( $s['enabled'], 'yes' ); ?>><?php esc_html_e( 'Show', 'wps-whatsapp-share' ); ?></option>
								<option value="no" <?php selected( $s['enabled'], 'no' ); ?>><?php esc_html_e( 'Hide', 'wps-whatsapp-share' ); ?></option>
							</select>
						</td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'WhatsApp Number', 'wps-whatsapp-share' ); ?></th>
						<td>
							<input type="text" class="regular-text" name="<?php echo esc_attr( self::OPTION ); ?>[whatsapp_number]" value="<?php echo esc_attr( $s['whatsapp_number'] ); ?>" placeholder="919876543210" />
							<p class="description"><?php esc_html_e( 'Country code + number, digits only. Example: 919876543210', 'wps-whatsapp-share' ); ?></p>
						</td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Button Color', 'wps-whatsapp-share' ); ?></th>
						<td>
							<input type="text" class="wps-color-picker" name="<?php echo esc_attr( self::OPTION ); ?>[color]" value="<?php echo esc_attr( $s['color'] ); ?>" data-default-color="#25D366" />
						</td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Message', 'wps-whatsapp-share' ); ?></th>
						<td>
							<input type="text" class="large-text" name="<?php echo esc_attr( self::OPTION ); ?>[message]" value="<?php echo esc_attr( $s['message'] ); ?>" />
							<p class="description"><?php esc_html_e( 'Sent as: {message} - {product title}. {url}', 'wps-whatsapp-share' ); ?></p>
						</td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Position', 'wps-whatsapp-share' ); ?></th>
						<td>
							<select name="<?php echo esc_attr( self::OPTION ); ?>[position]">
								<option value="after_add_to_cart" <?php selected( $s['position'], 'after_add_to_cart' ); ?>><?php esc_html_e( 'After Add to Cart', 'wps-whatsapp-share' ); ?></option>
								<option value="before_add_to_cart" <?php selected( $s['position'], 'before_add_to_cart' ); ?>><?php esc_html_e( 'Before Add to Cart', 'wps-whatsapp-share' ); ?></option>
								<option value="after_summary" <?php selected( $s['position'], 'after_summary' ); ?>><?php esc_html_e( 'After Product Summary', 'wps-whatsapp-share' ); ?></option>
							</select>
						</td>
					</tr>
				</table>
				<?php submit_button(); ?>
			</form>
		</div>
		<script>
		jQuery(function($) {
			$('.wps-color-picker').wpColorPicker();
		});
		</script>
		<?php
	}
}
