<?php

if (!defined('ABSPATH')) exit;

// Add menu
add_action('admin_menu', function () {
    add_menu_page(
        'WhatsApp Button Settings',
        'WhatsApp Button',
        'manage_options',
        'cwb-settings',
        'cwb_settings_page',
        'dashicons-whatsapp'
    );
});

// Settings UI
function cwb_settings_page() {
    $opt = get_option('cwb_settings');
?>

<div class="wrap">
    <h1>WhatsApp Button Settings</h1>

    <form method="post" action="options.php">
        <?php settings_fields('cwb_settings_group'); ?>

        <table class="form-table">

            <tr>
                <th>Phone Number</th>
                <td>
                    <input type="text" name="cwb_settings[number]" 
                    value="<?php echo esc_attr($opt['number'] ?? ''); ?>" placeholder="919999999999">
                </td>
            </tr>

            <tr>
                <th>Button Color</th>
                <td>
                    <input type="color" name="cwb_settings[color]" 
                    value="<?php echo esc_attr($opt['color'] ?? '#25D366'); ?>">
                </td>
            </tr>

            <tr>
                <th>Button Size (px)</th>
                <td>
                    <input type="number" name="cwb_settings[size]" 
                    value="<?php echo esc_attr($opt['size'] ?? '60'); ?>">
                </td>
            </tr>

            <tr>
                <th>Position</th>
                <td>
                    Top: <input type="number" name="cwb_settings[top]" value="<?php echo esc_attr($opt['top'] ?? ''); ?>"> px<br><br>
                    Bottom: <input type="number" name="cwb_settings[bottom]" value="<?php echo esc_attr($opt['bottom'] ?? '20'); ?>"> px<br><br>
                    Left: <input type="number" name="cwb_settings[left]" value="<?php echo esc_attr($opt['left'] ?? ''); ?>"> px<br><br>
                    Right: <input type="number" name="cwb_settings[right]" value="<?php echo esc_attr($opt['right'] ?? '20'); ?>"> px
                </td>
            </tr>

            <tr>
                <th>Padding</th>
                <td>
                    <input type="number" name="cwb_settings[padding]" 
                    value="<?php echo esc_attr($opt['padding'] ?? '10'); ?>">
                </td>
            </tr>

            <tr>
                <th>Icon Size</th>
                <td>
                    <input type="number" name="cwb_settings[icon_size]" 
                    value="<?php echo esc_attr($opt['icon_size'] ?? '30'); ?>">
                </td>
            </tr>

        </table>

        <?php submit_button(); ?>
    </form>
</div>

<?php
}