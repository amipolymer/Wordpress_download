<?php

if (!defined('ABSPATH')) exit;

// Load styles
add_action('wp_enqueue_scripts', function () {
    wp_enqueue_style('cwb-style', CWB_URL . 'public/style.css');
});

// Render button
add_action('wp_footer', function () {

    $number = cwb_get_option('number');
    if (!$number) return;

    $color = cwb_get_option('color', '#25D366');
    $size = cwb_get_option('size', '60');
    $padding = cwb_get_option('padding', '10');
    $icon = cwb_get_option('icon_size', '30');

    $style = "
        background:$color;
        width:{$size}px;
        height:{$size}px;
        padding:{$padding}px;
    ";

    if ($top = cwb_get_option('top')) $style .= "top:{$top}px;";
    if ($bottom = cwb_get_option('bottom', '20')) $style .= "bottom:{$bottom}px;";
    if ($left = cwb_get_option('left')) $style .= "left:{$left}px;";
    if ($right = cwb_get_option('right', '20')) $style .= "right:{$right}px;";

    ?>

    <a href="https://wa.me/<?php echo esc_attr($number); ?>" 
       class="cwb-btn" 
       target="_blank" 
       style="<?php echo esc_attr($style); ?>">
       
        <img src="<?php echo CWB_URL . 'assets/images/whatsapp.png'; ?>" 
             style="width:<?php echo esc_attr($icon); ?>px;">
    </a>

<?php
});