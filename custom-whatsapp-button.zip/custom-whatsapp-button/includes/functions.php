<?php

if (!defined('ABSPATH')) exit;

// Get settings safely
function cwb_get_option($key, $default = '') {
    $options = get_option('cwb_settings');
    return isset($options[$key]) ? $options[$key] : $default;
}