<?php

if (!defined('ABSPATH')) exit;

// Register settings
add_action('admin_init', function () {
    register_setting('cwb_settings_group', 'cwb_settings');
});