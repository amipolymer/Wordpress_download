<?php
/**
 * Plugin Name: Custom WhatsApp Button (Advanced)
 * Description: Floating WhatsApp button with full admin customization.
 * Version: 1.0
 */

if (!defined('ABSPATH')) exit;

// Paths
define('CWB_PATH', plugin_dir_path(__FILE__));
define('CWB_URL', plugin_dir_url(__FILE__));

// Includes
require_once CWB_PATH . 'includes/functions.php';
require_once CWB_PATH . 'includes/hooks.php';

// Admin
if (is_admin()) {
    require_once CWB_PATH . 'admin/settings-page.php';
}

// Frontend
require_once CWB_PATH . 'public/frontend.php';