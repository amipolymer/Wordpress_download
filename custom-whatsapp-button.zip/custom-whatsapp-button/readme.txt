Custom WhatsApp Button Plugin

Features:
- Floating WhatsApp button
- Full admin customization
- Position control
- Color & size control