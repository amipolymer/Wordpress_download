<?php
/**
 * Plugin Name: Brand Title Show
 * Description: Display product brand above breadcrumbs on single product pages.
 * Version:     1.0.3
 * Author:      Brand Title Show
 * Text Domain: brand-title-show
 * Requires Plugins: woocommerce
 */

defined( 'ABSPATH' ) || exit;

define( 'BTS_VERSION', '1.0.3' );
define( 'BTS_PATH', plugin_dir_path( __FILE__ ) );
define( 'BTS_URL', plugin_dir_url( __FILE__ ) );

require_once BTS_PATH . 'includes/class-bts-settings.php';
require_once BTS_PATH . 'includes/class-bts-render.php';

add_action( 'plugins_loaded', function () {
	if ( ! class_exists( 'WooCommerce' ) ) {
		return;
	}
	BTS_Settings::init();
	BTS_Render::init();
} );
