<?php
defined( 'ABSPATH' ) || exit;

class BTS_Render {

	private static $done = false;

	public static function init() {
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_action( 'wp', array( __CLASS__, 'register_hooks' ) );
	}

	public static function register_hooks() {
		if ( ! is_product() ) {
			return;
		}

		$settings = BTS_Settings::get();
		if ( 'yes' !== $settings['enabled'] ) {
			return;
		}

		$after = ( 'yes' === $settings['after_breadcrumb'] );
		$hooks = $after ? self::after_breadcrumb_hooks() : self::before_breadcrumb_hooks();

		foreach ( $hooks as $hook => $priority ) {
			add_action( $hook, array( __CLASS__, 'render' ), (int) $priority );
		}
	}

	private static function before_breadcrumb_hooks() {
		return apply_filters(
			'brand_title_show_hooks_before',
			array(
				'woocommerce_breadcrumb'          => 5,
				'klb_before_breadcrumb'           => 10,
				'blonwe_before_breadcrumb'      => 10,
				'klbtheme_before_breadcrumb'    => 10,
				'woocommerce_before_main_content' => 5,
			)
		);
	}

	private static function after_breadcrumb_hooks() {
		return apply_filters(
			'brand_title_show_hooks_after',
			array(
				'woocommerce_before_main_content' => 25,
				'klb_after_breadcrumb'            => 10,
				'blonwe_after_breadcrumb'         => 10,
				'klbtheme_after_breadcrumb'     => 10,
			)
		);
	}

	public static function assets() {
		if ( ! is_product() ) {
			return;
		}

		$settings = BTS_Settings::get();
		if ( 'yes' !== $settings['enabled'] ) {
			return;
		}

		wp_enqueue_style( 'bts-front', BTS_URL . 'assets/css/front.css', array(), BTS_VERSION );
	}

	public static function render() {
		if ( self::$done || ! is_product() ) {
			return;
		}

		$settings = BTS_Settings::get();
		if ( 'yes' !== $settings['enabled'] ) {
			return;
		}

		$brand = self::get_brand( get_the_ID(), $settings['taxonomy'] );
		if ( ! $brand ) {
			return;
		}

		$html = self::build_html( $brand, $settings );
		if ( '' === $html ) {
			return;
		}

		self::$done = true;
		echo apply_filters( 'brand_title_show_output', $html, $brand, $settings ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	private static function build_html( $brand, $settings ) {
		$brand_slug  = sanitize_title( $brand->name );
		$align       = sanitize_html_class( $settings['alignment'] );
		$brand_class = sanitize_html_class( 'brand-' . $brand_slug . '-section' );
		$classes     = array_filter(
			array(
				$settings['wrapper_class'],
				$brand_class,
				'bts-align-' . $align,
			)
		);

		$classes    = apply_filters( 'brand_title_show_wrapper_classes', $classes, $brand, $settings );
		$show_image = in_array( $settings['display_type'], array( 'image_only', 'image_title' ), true );
		$show_title = in_array( $settings['display_type'], array( 'title_only', 'image_title' ), true );
		$html       = '<div class="' . esc_attr( implode( ' ', $classes ) ) . '">';

		if ( $show_image ) {
			$image_url = self::get_brand_image( $brand->term_id );
			if ( $image_url ) {
				$html .= sprintf(
					'<img src="%s" alt="%s" class="%s" />',
					esc_url( $image_url ),
					esc_attr( $brand->name ),
					esc_attr( $settings['image_class'] )
				);
			} elseif ( 'image_only' === $settings['display_type'] ) {
				return '';
			}
		}

		if ( $show_title ) {
			$html .= sprintf(
				'<h1 class="%s">%s</h1>',
				esc_attr( $settings['title_class'] ),
				esc_html( $brand->name )
			);
		}

		$html .= '</div>';

		return $html;
	}

	private static function get_brand( $product_id, $taxonomy ) {
		if ( ! taxonomy_exists( $taxonomy ) ) {
			return null;
		}
		$terms = get_the_terms( $product_id, $taxonomy );
		if ( empty( $terms ) || is_wp_error( $terms ) ) {
			return null;
		}
		return apply_filters( 'brand_title_show_brand_term', $terms[0], $product_id, $taxonomy );
	}

	private static function get_brand_image( $term_id ) {
		$thumb_id = get_term_meta( $term_id, 'thumbnail_id', true );
		if ( $thumb_id ) {
			$url = wp_get_attachment_image_url( (int) $thumb_id, 'medium' );
			if ( $url ) {
				return apply_filters( 'brand_title_show_image_url', $url, $term_id );
			}
		}

		$pwb = get_term_meta( $term_id, 'pwb_brand_image', true );
		if ( $pwb ) {
			if ( is_numeric( $pwb ) ) {
				$url = wp_get_attachment_image_url( (int) $pwb, 'medium' );
			} else {
				$url = esc_url_raw( $pwb );
			}
			if ( $url ) {
				return apply_filters( 'brand_title_show_image_url', $url, $term_id );
			}
		}

		return apply_filters( 'brand_title_show_image_url', '', $term_id );
	}
}
