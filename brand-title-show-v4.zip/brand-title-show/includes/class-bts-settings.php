<?php
defined( 'ABSPATH' ) || exit;

class BTS_Settings {

	const OPTION = 'bts_settings';

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_init', array( __CLASS__, 'register' ) );
	}

	public static function defaults() {
		return apply_filters(
			'brand_title_show_default_settings',
			array(
				'enabled'          => 'yes',
				'after_breadcrumb' => 'no',
				'display_type'     => 'title_only',
				'alignment'        => 'left',
				'taxonomy'         => 'product_brand',
				'wrapper_class'    => 'brand-section',
				'additional_class' => '',
				'title_class'      => 'brand-title',
				'image_class'      => 'brand-image',
			)
		);
	}

	public static function get() {
		return wp_parse_args( get_option( self::OPTION, array() ), self::defaults() );
	}

	public static function menu() {
		add_options_page(
			__( 'Brand Title Show', 'brand-title-show' ),
			__( 'Brand Title Show', 'brand-title-show' ),
			'manage_options',
			'brand-title-show',
			array( __CLASS__, 'page' )
		);
	}

	public static function register() {
		register_setting( 'bts_settings_group', self::OPTION, array( __CLASS__, 'sanitize' ) );
	}

	public static function sanitize( $input ) {
		$out   = self::defaults();
		$types = array( 'title_only', 'image_only', 'image_title' );
		$align = array( 'left', 'center', 'right' );
		$tax   = array( 'product_brand', 'pwb-brand' );

		$out['enabled']          = ! empty( $input['enabled'] ) && 'yes' === $input['enabled'] ? 'yes' : 'no';
		$out['after_breadcrumb'] = ! empty( $input['after_breadcrumb'] ) && 'yes' === $input['after_breadcrumb'] ? 'yes' : 'no';
		$out['display_type']     = in_array( $input['display_type'] ?? '', $types, true ) ? $input['display_type'] : $out['display_type'];
		$out['alignment']        = in_array( $input['alignment'] ?? '', $align, true ) ? $input['alignment'] : $out['alignment'];
		$out['taxonomy']         = in_array( $input['taxonomy'] ?? '', $tax, true ) ? $input['taxonomy'] : $out['taxonomy'];
		$out['wrapper_class']    = sanitize_html_class( $input['wrapper_class'] ?? $out['wrapper_class'] );
		$out['additional_class'] = sanitize_html_class( $input['additional_class'] ?? $out['additional_class'] );
		$out['title_class']      = sanitize_html_class( $input['title_class'] ?? $out['title_class'] );
		$out['image_class']      = sanitize_html_class( $input['image_class'] ?? $out['image_class'] );

		return apply_filters( 'brand_title_show_sanitize_settings', $out, $input );
	}

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$s = self::get();
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Brand Title Show', 'brand-title-show' ); ?></h1>
			<form method="post" action="options.php">
				<?php settings_fields( 'bts_settings_group' ); ?>
				<table class="form-table">
					<tr>
						<th><?php esc_html_e( 'Brand Section', 'brand-title-show' ); ?></th>
						<td>
							<select name="<?php echo esc_attr( self::OPTION ); ?>[enabled]">
								<option value="yes" <?php selected( $s['enabled'], 'yes' ); ?>><?php esc_html_e( 'Show', 'brand-title-show' ); ?></option>
								<option value="no" <?php selected( $s['enabled'], 'no' ); ?>><?php esc_html_e( 'Hide', 'brand-title-show' ); ?></option>
							</select>
						</td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Show After Breadcrumb', 'brand-title-show' ); ?></th>
						<td>
							<select name="<?php echo esc_attr( self::OPTION ); ?>[after_breadcrumb]">
								<option value="no" <?php selected( $s['after_breadcrumb'], 'no' ); ?>><?php esc_html_e( 'No — Before breadcrumb', 'brand-title-show' ); ?></option>
								<option value="yes" <?php selected( $s['after_breadcrumb'], 'yes' ); ?>><?php esc_html_e( 'Yes — After breadcrumb', 'brand-title-show' ); ?></option>
							</select>
						</td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Display Type', 'brand-title-show' ); ?></th>
						<td>
							<select name="<?php echo esc_attr( self::OPTION ); ?>[display_type]">
								<option value="title_only" <?php selected( $s['display_type'], 'title_only' ); ?>><?php esc_html_e( 'Title Only', 'brand-title-show' ); ?></option>
								<option value="image_only" <?php selected( $s['display_type'], 'image_only' ); ?>><?php esc_html_e( 'Image Only', 'brand-title-show' ); ?></option>
								<option value="image_title" <?php selected( $s['display_type'], 'image_title' ); ?>><?php esc_html_e( 'Image + Title', 'brand-title-show' ); ?></option>
							</select>
						</td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Alignment', 'brand-title-show' ); ?></th>
						<td>
							<select name="<?php echo esc_attr( self::OPTION ); ?>[alignment]">
								<option value="left" <?php selected( $s['alignment'], 'left' ); ?>><?php esc_html_e( 'Left', 'brand-title-show' ); ?></option>
								<option value="center" <?php selected( $s['alignment'], 'center' ); ?>><?php esc_html_e( 'Center', 'brand-title-show' ); ?></option>
								<option value="right" <?php selected( $s['alignment'], 'right' ); ?>><?php esc_html_e( 'Right', 'brand-title-show' ); ?></option>
							</select>
						</td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Brand Taxonomy', 'brand-title-show' ); ?></th>
						<td>
							<select name="<?php echo esc_attr( self::OPTION ); ?>[taxonomy]">
								<option value="product_brand" <?php selected( $s['taxonomy'], 'product_brand' ); ?>>product_brand</option>
								<option value="pwb-brand" <?php selected( $s['taxonomy'], 'pwb-brand' ); ?>>pwb-brand</option>
							</select>
						</td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Wrapper Class', 'brand-title-show' ); ?></th>
						<td><input type="text" class="regular-text" name="<?php echo esc_attr( self::OPTION ); ?>[wrapper_class]" value="<?php echo esc_attr( $s['wrapper_class'] ); ?>" /></td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Brand Class', 'brand-title-show' ); ?></th>
						<td><p class="description"><?php esc_html_e( 'Auto-generated as brand-{slug}-section (e.g. brand-revami-section).', 'brand-title-show' ); ?></p></td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Title Class', 'brand-title-show' ); ?></th>
						<td><input type="text" class="regular-text" name="<?php echo esc_attr( self::OPTION ); ?>[title_class]" value="<?php echo esc_attr( $s['title_class'] ); ?>" /></td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Image Class', 'brand-title-show' ); ?></th>
						<td><input type="text" class="regular-text" name="<?php echo esc_attr( self::OPTION ); ?>[image_class]" value="<?php echo esc_attr( $s['image_class'] ); ?>" /></td>
					</tr>
				</table>
				<?php submit_button(); ?>
			</form>
		</div>
		<?php
	}
}
