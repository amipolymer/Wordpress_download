<?php
/**
 * Plugin Name: Custom Shipping GST Show For WooCommerce Settings
 * Plugin URI: #
 * Description: Custom GST calculation for WooCommerce shipping with admin-controlled labels CGST/SGST support show on Checkout/Cart or Invoice PDF section [Edit-> WooCommerce → Settings → Shipping → GST Shipping].
 * Version: 3.0
 * Author: Self Developer
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Default options
 */
function csgs_default_options() {

    return array(
        'product_label'      => 'Product Cost:',
        'shipping_label'     => 'Shipping Charges:',
        'subtotal_label'     => 'Sub Total:',
        'tax_label'          => 'Shipping Tax',
        'grand_total_label'  => 'Grand Total:',
        'gst_rate'           => '18',
    );
}

/**
 * Get option helper
 */
function csgs_get_option($key) {

    $defaults = csgs_default_options();

    return get_option(
        'csgs_settings_' . $key,
        isset($defaults[$key]) ? $defaults[$key] : ''
    );
}

/**
 * Add GST Shipping section in WooCommerce → Settings → Shipping
 */
add_filter('woocommerce_get_sections_shipping', 'csgs_add_shipping_section');

function csgs_add_shipping_section($sections) {

    $sections['csgs_settings'] = __('GST Shipping', 'woocommerce');

    return $sections;
}

/**
 * GST Shipping settings fields
 */
add_filter('woocommerce_get_settings_shipping', 'csgs_shipping_settings', 10, 2);

function csgs_shipping_settings($settings, $current_section) {

    if ($current_section === 'csgs_settings') {

        $settings = array(

            array(
                'name' => __('GST Shipping Settings', 'woocommerce'),
                'type' => 'title',
                'desc' => __('Manage shipping GST labels and GST rate.', 'woocommerce'),
                'id'   => 'csgs_settings_section',
            ),

            array(
                'name'    => __('Product Label', 'woocommerce'),
                'id'      => 'csgs_settings_product_label',
                'type'    => 'text',
                'default' => 'Product Cost:',
            ),

            array(
                'name'    => __('Shipping Label', 'woocommerce'),
                'id'      => 'csgs_settings_shipping_label',
                'type'    => 'text',
                'default' => 'Shipping Charges:',
            ),

            array(
                'name'    => __('Subtotal Label', 'woocommerce'),
                'id'      => 'csgs_settings_subtotal_label',
                'type'    => 'text',
                'default' => 'Sub Total:',
            ),

            array(
                'name'    => __('Shipping Tax Label', 'woocommerce'),
                'id'      => 'csgs_settings_tax_label',
                'type'    => 'text',
                'default' => 'Shipping Tax',
            ),

            array(
                'name'    => __('Grand Total Label', 'woocommerce'),
                'id'      => 'csgs_settings_grand_total_label',
                'type'    => 'text',
                'default' => 'Grand Total:',
            ),

            array(
                'name'              => __('GST Rate (%)', 'woocommerce'),
                'id'                => 'csgs_settings_gst_rate',
                'type'              => 'number',
                'default'           => '18',
                'custom_attributes' => array(
                    'step' => '0.01',
                    'min'  => '0',
                ),
            ),

            array(
                'type' => 'sectionend',
                'id'   => 'csgs_settings_section',
            ),
        );
    }

    return $settings;
}

/**
 * Force shipping tax class
 */
add_filter('woocommerce_shipping_tax_class', function ($tax_class) {

    return 'standard';

});

/**
 * Force shipping GST
 */
add_filter('woocommerce_package_rates', function ($rates, $package) {

    $gst = floatval(csgs_get_option('gst_rate'));

    foreach ($rates as $rate_key => $rate) {

        $shipping_cost = $rate->cost;

        $shipping_tax = ($shipping_cost * $gst) / 100;

        $rate->taxes = array(
            1 => $shipping_tax,
        );
    }

    return $rates;

}, 20, 2);

/**
 * Customize order totals
 */
add_filter('woocommerce_get_order_item_totals', function ($total_rows, $order, $tax_display) {

    $new = array();

    /**
     * Product Cost
     */
    $new['cart_subtotal'] = array(
        'label' => csgs_get_option('product_label'),
        'value' => wc_price($order->get_subtotal()),
    );

    /**
     * Shipping Charges
     */
    $new['shipping'] = array(
        'label' => csgs_get_option('shipping_label'),
        'value' => wc_price($order->get_shipping_total()),
    );

    /**
     * Subtotal
     */
    $new['subtotal'] = array(
        'label' => csgs_get_option('subtotal_label'),
        'value' => wc_price(
            $order->get_subtotal() + $order->get_shipping_total()
        ),
    );

    /**
     * Tax labels
     */
    foreach ($order->get_tax_totals() as $code => $tax_total) {

        $label = $tax_total->label;

        $is_shipping_tax = false;

        foreach ($order->get_items('shipping') as $shipping_item) {

            $shipping_taxes = $shipping_item->get_taxes();

            if (!empty($shipping_taxes['total'])) {

                foreach ($shipping_taxes['total'] as $tax_id => $amount) {

                    if ((float) $amount === (float) $tax_total->amount) {

                        $is_shipping_tax = true;
                        break;
                    }
                }
            }
        }

        /**
         * Change shipping tax label
         */
        if ($is_shipping_tax) {

            $label = csgs_get_option('tax_label') . ' ' . csgs_get_option('gst_rate') . '%';
        }

        $new[$code] = array(
            'label' => $label . ':',
            'value' => $tax_total->formatted_amount,
        );
    }

    /**
     * Grand Total
     */
    $new['order_total'] = array(
        'label' => csgs_get_option('grand_total_label'),
        'value' => wc_price($order->get_total()),
    );

    return $new;

}, 20, 3);

/**
 * Checkout / Cart tax label customization
 */
add_filter('woocommerce_cart_tax_totals', 'custom_checkout_shipping_tax_label', 10, 2);

function custom_checkout_shipping_tax_label($tax_totals, $cart) {

    $shipping_taxes = WC()->cart->get_shipping_taxes();

    foreach ($tax_totals as $key => $tax) {

        foreach ($shipping_taxes as $tax_id => $shipping_tax_amount) {

            if ((float) $tax->amount === (float) $shipping_tax_amount) {

                $tax->label = csgs_get_option('tax_label') . ' ' . csgs_get_option('gst_rate') . '%';
            }
        }
    }

    return $tax_totals;
}
