=== Custom Shipping GST Show For WooCommerce ===
Version: 2.0
Author: Custom Developer

Allows admin control of GST labels and rate from dashboard.
