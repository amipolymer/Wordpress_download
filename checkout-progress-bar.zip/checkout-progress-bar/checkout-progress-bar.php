<?php
/**
 * Plugin Name: Checkout Progress Loader
 * Description: Show centered progress bar with message on WooCommerce checkout processing
 * Version: 1.0
 */

if (!defined('ABSPATH')) exit;

// Add Loader HTML
add_action('wp_footer', function () {
    if (is_checkout()) {
        ?>
        <div id="checkout-progress-overlay">
            <div class="progress-box">
                <div class="progress-text">Your order is being processed</div>
                <div class="progress-subtext">Please do not refresh or go back</div>

                <div class="progress-bar">
                    <div class="progress-fill"></div>
                </div>
            </div>
        </div>
        <?php
    }
});

// Add CSS
add_action('wp_head', function () {
    if (is_checkout()) {
        ?>
        <style>
        #checkout-progress-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(255,255,255,0.85);
            backdrop-filter: blur(6px);
            display: none;
            align-items: center;
            justify-content: center;
            z-index: 9999;
        }

        .progress-box {
            width: 320px;
            text-align: center;
            font-family: Arial, sans-serif;
        }

        .progress-text {
            font-size: 16px;
            font-weight: 600;
            margin-bottom: 10px;
            color: #333;
        }

        .progress-subtext {
            font-size: 13px;
            color: #777;
            margin-bottom: 15px;
        }

        .progress-bar {
            width: 100%;
            height: 6px;
            background: #eee;
            border-radius: 50px;
            overflow: hidden;
        }

        .progress-fill {
            width: 0%;
            height: 100%;
            background: #000;
            animation: progressAnim 3.5s ease-in-out forwards;
        }

        @keyframes progressAnim {
            0% { width: 0%; }
            40% { width: 50%; }
            70% { width: 80%; }
            100% { width: 95%; }
        }
        </style>
        <?php
    }
});

// Add JS
add_action('wp_footer', function () {
    if (is_checkout()) {
        ?>
        <script>
        jQuery(function($){

            // Show loader on place order
            $('form.checkout').on('checkout_place_order', function(){
                $('#checkout-progress-overlay').css('display','flex');

                // Disable button to prevent double click
                $('#place_order').prop('disabled', true).text('Processing...');
            });

            // Hide loader if error occurs
            $(document.body).on('checkout_error', function(){
                $('#checkout-progress-overlay').hide();

                $('#place_order').prop('disabled', false).text('Place order');
            });

        });
        </script>
        <?php
    }
});