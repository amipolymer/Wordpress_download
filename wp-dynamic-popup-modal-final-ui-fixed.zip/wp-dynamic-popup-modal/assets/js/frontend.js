jQuery(document).ready(function ($) {

    if (
        dpmData.mobileDisable == 1 &&
        window.innerWidth < 768
    ) {
        return;
    }

    setTimeout(function () {

        $('#dpm-popup-overlay').fadeIn();
        $('#dpm-popup-modal').fadeIn();

    }, dpmData.delay);

    $('#dpm-close-popup').click(function () {
        closePopup();
    });

    $('#dpm-popup-overlay').click(function () {
        closePopup();
    });

    function closePopup() {
        $('#dpm-popup-overlay').fadeOut();
        $('#dpm-popup-modal').fadeOut();
    }

});
