jQuery(document).ready(function ($) {

    function toggleDependentField() {

        if ($('#dpm_show_close_button').is(':checked')) {
            $('.dpm-dependent-row').show();
        } else {
            $('.dpm-dependent-row').hide();
        }
    }

    toggleDependentField();

    $('#dpm_show_close_button').change(function () {
        toggleDependentField();
    });

});
