<?php
/*
Plugin Name: Dynamic Popup Modal
Plugin URI: https://example.com
Description: Custom responsive popup modal with Contact Form 7 support.
Version: 1.0
Author: Ami Polymer
Text Domain: dynamic-popup-modal
*/

if (!defined('ABSPATH')) {
    exit;
}

class DynamicPopupModal {

    public function __construct() {

        add_action('admin_menu', [$this, 'admin_menu']);
        add_action('admin_init', [$this, 'register_settings']);

        add_action('wp_enqueue_scripts', [$this, 'frontend_assets']);
        add_action('admin_enqueue_scripts', [$this, 'admin_assets']);

        add_action('wp_footer', [$this, 'render_popup']);
    }

    public function admin_menu() {
        add_menu_page(
            'Dynamic Popup',
            'Dynamic Popup',
            'manage_options',
            'dynamic-popup-modal',
            [$this, 'settings_page'],
            'dashicons-format-status',
            30
        );
    }

    public function register_settings() {

        register_setting('dynamic_popup_group', 'dpm_enable_popup');
        register_setting('dynamic_popup_group', 'dpm_popup_title');
        register_setting('dynamic_popup_group', 'dpm_popup_description');
        register_setting('dynamic_popup_group', 'dpm_popup_delay');
        register_setting('dynamic_popup_group', 'dpm_selected_form');
        register_setting('dynamic_popup_group', 'dpm_show_close_button');
        register_setting('dynamic_popup_group', 'dpm_overlay_close');
        register_setting('dynamic_popup_group', 'dpm_mobile_disable');
    }

    public function admin_assets() {
        wp_enqueue_style(
            'dpm-admin-css',
            plugin_dir_url(__FILE__) . 'assets/css/admin.css'
        );

        wp_enqueue_script(
            'dpm-admin-js',
            plugin_dir_url(__FILE__) . 'assets/js/admin.js',
            ['jquery'],
            false,
            true
        );
    }

    public function frontend_assets() {

        wp_enqueue_style(
            'dpm-frontend-css',
            plugin_dir_url(__FILE__) . 'assets/css/frontend.css'
        );

        wp_enqueue_script(
            'dpm-frontend-js',
            plugin_dir_url(__FILE__) . 'assets/js/frontend.js',
            ['jquery'],
            false,
            true
        );

        wp_localize_script('dpm-frontend-js', 'dpmData', [
            'delay' => get_option('dpm_popup_delay', 3000),
            'mobileDisable' => get_option('dpm_mobile_disable', 0),
        ]);
    }

    public function settings_page() {

        $forms = get_posts([
            'post_type' => 'wpcf7_contact_form',
            'posts_per_page' => -1
        ]);
        ?>

        <div class="wrap dpm-admin-wrap">
            <h1>Dynamic Popup Modal Settings</h1>

            <form method="post" action="options.php">

                <?php settings_fields('dynamic_popup_group'); ?>

                <table class="form-table">

                    <tr>
                        <th>Enable Popup</th>
                        <td>
                            <label class="dpm-switch">
                                <input type="checkbox" name="dpm_enable_popup" value="1"
                                    <?php checked(1, get_option('dpm_enable_popup')); ?> />
                                <span class="dpm-slider"></span>
                            </label>
                        </td>
                    </tr>

                    <tr>
                        <th>Popup Title</th>
                        <td>
                            <input type="text"
                                name="dpm_popup_title"
                                class="regular-text"
                                value="<?php echo esc_attr(get_option('dpm_popup_title')); ?>">
                        </td>
                    </tr>

                    <tr>
                        <th>Description</th>
                        <td>
                            <textarea name="dpm_popup_description"
                                rows="4"
                                class="large-text"><?php echo esc_textarea(get_option('dpm_popup_description')); ?></textarea>
                        </td>
                    </tr>

                    <tr>
                        <th>Popup Delay (ms)</th>
                        <td>
                            <input type="number"
                                name="dpm_popup_delay"
                                value="<?php echo esc_attr(get_option('dpm_popup_delay', 3000)); ?>">
                        </td>
                    </tr>

                    <tr>
                        <th>Select Contact Form</th>
                        <td>
                            <select name="dpm_selected_form">

                                <option value="">Select Form</option>

                                <?php foreach ($forms as $form) : ?>

                                    <option value="<?php echo $form->ID; ?>"
                                        <?php selected(get_option('dpm_selected_form'), $form->ID); ?>>
                                        <?php echo esc_html($form->post_title); ?>
                                    </option>

                                <?php endforeach; ?>

                            </select>
                        </td>
                    </tr>

                    <tr>
                        <th>Show Close Button</th>
                        <td>
                            <input type="checkbox"
                                id="dpm_show_close_button"
                                name="dpm_show_close_button"
                                value="1"
                                <?php checked(1, get_option('dpm_show_close_button')); ?> />
                        </td>
                    </tr>

                    <tr class="dpm-dependent-row">
                        <th>Overlay Click Close</th>
                        <td>
                            <input type="checkbox"
                                name="dpm_overlay_close"
                                value="1"
                                <?php checked(1, get_option('dpm_overlay_close')); ?> />
                        </td>
                    </tr>

                    <tr>
                        <th>Disable on Mobile</th>
                        <td>
                            <input type="checkbox"
                                name="dpm_mobile_disable"
                                value="1"
                                <?php checked(1, get_option('dpm_mobile_disable')); ?> />
                        </td>
                    </tr>

                </table>

                <?php submit_button(); ?>

            </form>
        </div>

        <?php
    }

    public function render_popup() {

        if (!get_option('dpm_enable_popup')) {
            return;
        }

        $form_id = get_option('dpm_selected_form');

        include plugin_dir_path(__FILE__) . 'templates/popup-template.php';
    }
}

new DynamicPopupModal();
