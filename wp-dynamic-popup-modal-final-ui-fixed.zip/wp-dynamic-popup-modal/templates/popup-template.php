<div id="dpm-popup-overlay"></div>

<div id="dpm-popup-modal">

    <?php if (get_option('dpm_show_close_button')) : ?>
        <button id="dpm-close-popup">×</button>
    <?php endif; ?>

    <div class="dpm-popup-content">

        <h2>
            <?php echo esc_html(get_option('dpm_popup_title')); ?>
        </h2>

        <p>
            <?php echo esc_html(get_option('dpm_popup_description')); ?>
        </p>

        <div class="dpm-form-area">
            <?php
            if ($form_id) {
                echo do_shortcode('[contact-form-7 id="' . $form_id . '"]');
            }
            ?>
        </div>

    </div>

</div>
