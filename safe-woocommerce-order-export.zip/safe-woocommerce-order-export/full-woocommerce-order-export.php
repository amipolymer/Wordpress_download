<?php
/*
Plugin Name: Safe WooCommerce Order Export
Description: Advanced WooCommerce export with coupon, GST, price breakdown, shipping charges, billing & shipping info, and stored in export-order folder.
Version: 6.5
Author: Rishikesh By AMI
*/

if (!defined('ABSPATH')) exit;

class Safe_WC_Order_Export {

    private $folder_name = 'export-order';

    public function __construct() {
        add_action('admin_menu', array($this, 'add_menu'));
    }

    public function add_menu() {
        add_submenu_page(
            'woocommerce',
            'Safe Order Export',
            'Safe Order Export',
            'manage_woocommerce',
            'safe-wc-order-export',
            array($this, 'export_page')
        );
    }

    public function export_page() {

        if (isset($_POST['generate_csv'])) {
            $file_url = $this->generate_csv_file();

            if ($file_url) {
                echo '<div class="notice notice-success">
                        <p>Export Ready: <a href="'.$file_url.'" target="_blank">Download CSV</a></p>
                      </div>';
            } else {
                echo '<div class="notice notice-error"><p>Export failed. Check folder permissions.</p></div>';
            }
        }
        ?>
        <div class="wrap">
            <h1>Safe WooCommerce Order Export</h1>
            <form method="post">
                <input type="submit" name="generate_csv" class="button button-primary" value="Generate CSV">
            </form>
        </div>
        <?php
    }

    private function generate_csv_file() {

        if (!class_exists('WooCommerce')) return false;

        @ini_set('memory_limit', '512M');
        @set_time_limit(300);

        $upload_dir = wp_upload_dir();
        $export_path = $upload_dir['basedir'] . '/' . $this->folder_name;
        if (!file_exists($export_path)) {
            wp_mkdir_p($export_path);
        }

        $filename = 'woocommerce-export-' . date('Y-m-d-H-i-s') . '.csv';
        $file_path = $export_path . '/' . $filename;
        $file_url  = $upload_dir['baseurl'] . '/' . $this->folder_name . '/' . $filename;

        $output = fopen($file_path, 'w');
        if (!$output) return false;

        // CSV Headers
        fputcsv($output, array(
            'Order ID',
            'Sub-Order',
            'Order Date',
            'Status',

            'Coupon Used',
            'Coupon Code',
            'Coupon Discount',

            'GST Number',
            'Customer Type',

            'Customer Name',
            'Product Name',
            'Product Type',
            'SKU',
            'Qty',

            'Product Unit Cost',
            'Discount',
            'GST %',
            'GST Amount',
            'Unit+GST Amount',
            'Line Total (Excl Tax)',
            'Line Total (Incl Tax)',
            'Shipping Charges',
            'Order Total',

            // Billing & Payment Info
            'B-Email',
            'B-Phone',
            'B-State',
            'B-City',
            'B-Address',
            'B-Pincode',
            'Payment Mode',
            'Payment Type',

            // Shipping Info
            'S-Email',
            'S-Phone',
            'S-State',
            'S-City',
            'S-Address',
            'S-Pincode'
        ));

        $page = 1;
        $per_page = 100;

        do {

            $orders = wc_get_orders(array(
                'limit' => $per_page,
                'page'  => $page,
                'orderby' => 'date',
                'order' => 'DESC',
                'return' => 'objects'
            ));

            if (empty($orders)) break;

            foreach ($orders as $order) {

                $coupon_codes = $order->get_coupon_codes();
                $coupon_used = !empty($coupon_codes) ? 'Yes' : 'No';
                $coupon_code = !empty($coupon_codes) ? implode(', ', $coupon_codes) : 'N/A';
                $coupon_discount = $order->get_discount_total();

                $gst_number = $order->get_meta('_billing_gst');
                if (empty($gst_number)) $gst_number = $order->get_meta('billing_gst');
                $customer_type = !empty($gst_number) ? 'B2B' : 'B2C';

                $shipping_total = $order->get_shipping_total();

                $items = $order->get_items();
                $sub_order_index = 1;

                foreach ($items as $item) {

                    $product = $item->get_product();
                    $qty = $item->get_quantity();

                    $subtotal = $item->get_subtotal();
                    $line_total = $item->get_total();
                    $tax = $item->get_total_tax();
                    $line_total_incl_tax = $line_total + $tax;
                    $discount = $subtotal - $line_total;
                    $product_price = $qty > 0 ? ($subtotal / $qty) : 0;

                    $unit_gst_amount = $qty > 0 ? ($tax / $qty) : 0;
                    $unit_plus_gst = $product_price + $unit_gst_amount;

                    $product_type = '';
                    if ($product) {
                        $product_type = $product->is_type('variation') ? 'Variable' : ucfirst($product->get_type());
                    }

                    // Sub-Order number
                    $sub_order = count($items) > 1 ? $order->get_id().'-'.$sub_order_index : 'N/A';
                    $sub_order_index++;

                    // Billing & Shipping details
                    $billing_email = $order->get_billing_email() ?: 'N/A';
                    $billing_phone = $order->get_billing_phone() ?: 'N/A';
                    $billing_state = $order->get_billing_state() ?: 'N/A';
                    $billing_city = $order->get_billing_city() ?: 'N/A';
                    $billing_address = $order->get_formatted_billing_address() ?: 'N/A';
                    $billing_pincode = $order->get_billing_postcode() ?: 'N/A';

                  //  $shipping_email = $order->get_shipping_email() ?: $billing_email; // fallback
                    // $shipping_phone = $order->get_shipping_phone() ?: $billing_phone; // fallback
                    
                    $shipping_email = $order->get_billing_email() ?: 'N/A';
                    $shipping_phone = $order->get_billing_phone() ?: 'N/A';
                    
                    $shipping_state = $order->get_shipping_state() ?: 'N/A';
                    $shipping_city = $order->get_shipping_city() ?: 'N/A';
                    $shipping_address = $order->get_formatted_shipping_address() ?: 'N/A';
                    $shipping_pincode = $order->get_shipping_postcode() ?: 'N/A';

                    $payment_method = $order->get_payment_method_title() ?: 'N/A';
                    $payment_type = $order->get_payment_method() ?: 'N/A';

                    fputcsv($output, array(
                        $order->get_id(),
                        $sub_order,
                        $order->get_date_created() ? $order->get_date_created()->date('Y-m-d H:i:s') : '',
                        wc_get_order_status_name($order->get_status()),

                        $coupon_used,
                        $coupon_code,
                        round($coupon_discount, 2),

                        $gst_number,
                        $customer_type,

                        $order->get_formatted_billing_full_name(),
                        $item->get_name(),
                        $product_type,
                        $product ? $product->get_sku() : '',
                        $qty,

                        round($product_price, 2),
                        round($discount, 2),
                        $qty > 0 ? round(($tax / $qty) / $product_price * 100, 2) : 0, // GST %
                        round($unit_gst_amount, 2),
                        round($unit_plus_gst, 2),

                        round($line_total, 2),
                        round($line_total_incl_tax, 2),
                        round($shipping_total, 2),
                        $order->get_total(),

                        // Billing
                        $billing_email,
                        $billing_phone,
                        $billing_state,
                        $billing_city,
                        $billing_address,
                        $billing_pincode,
                        $payment_method,
                        $payment_type,

                        // Shipping
                        $shipping_email,
                        $shipping_phone,
                        $shipping_state,
                        $shipping_city,
                        $shipping_address,
                        $shipping_pincode
                    ));
                }
            }

            $page++;

        } while (count($orders) === $per_page);

        fclose($output);

        return $file_url;
    }
}

new Safe_WC_Order_Export();
